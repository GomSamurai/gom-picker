@echo off
title GOM Color Picker Pro - Version Portable
cd /d "%~dp0"
echo ========================================================
echo    GOM COLOR PICKER PRO - VERSION PORTABLE 100% OFFLINE
echo ========================================================
if exist "GOM Color Picker Pro.exe" (
    start "" "GOM Color Picker Pro.exe"
    exit
)
start "" index.html